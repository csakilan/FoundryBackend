### This is my test repo for Foundry CI/CD

##### The first push failed to be sensed by the webhook, let's try again

##### Yay, the last push was successful and gave me a payload. Now that I've tried triggering the rest of our CI/CD pipeline in the code once a push is made to this repo, let's test if it really triggers the whole pipeline.

##### Another new push

##### Anddd another push

##### This time, I've automated the webhook using the GitHub API and personal access token. Let's see if this automated webhook can still trigger the rest of the CI/CD pipeline

##### hello

# more changes!

#### hmmi

### okayyy works again fire!!!!!!

## ello

## am i the goat?

## HELL YEAAA

# hgakghka
