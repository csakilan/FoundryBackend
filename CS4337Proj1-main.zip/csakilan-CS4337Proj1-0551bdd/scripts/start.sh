#!/bin/bash
set -euo pipefail
cd /home/ubuntu/app
source .venv/bin/activate
nohup uvicorn main:app --host 0.0.0.0 --port 8000 > /var/log/fastapi.out 2>&1 &


