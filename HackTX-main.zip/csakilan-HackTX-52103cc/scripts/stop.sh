#!/bin/bash
pkill -f "uvicorn|gunicorn|fastapi" || true

