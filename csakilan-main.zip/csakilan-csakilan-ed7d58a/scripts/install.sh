
#!/bin/bash
set -e
cd /home/ubuntu/app

sudo apt-get update -y
sudo apt-get install -y python3-venv python3-pip

python3 -m venv .venv
. .venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt
pip install uvicorn


