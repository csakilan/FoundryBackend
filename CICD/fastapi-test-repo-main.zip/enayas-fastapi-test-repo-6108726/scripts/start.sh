#!/bin/bash
set -e
cd /home/ec2-user/app/frontend
nohup npm start > /var/log/nextjs.log 2>&1 &
