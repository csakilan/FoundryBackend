#!/bin/bash 
set -e
cd /home/ec2-user/app/frontend

if ! command -v node &> /dev/null; then
    sudo dnf install -y nodejs20
fi

echo "Reinstalling dependencies..."
rm -rf node_modules
npm install

echo " Installation complete"
