#!/bin/bash
pkill -f "node.*next" || true
